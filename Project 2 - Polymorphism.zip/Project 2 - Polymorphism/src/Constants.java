/**
 * Documents the Constants used throughout the project.
 * @author Marlon Vergara
 * @author Luis Castellanos
 */
public class Constants {
    /** Makes a private Constants object */
    private Constants(){}

    /** Quadrennial amount */
    public static final int QUADRENNIAL = 4;

    /** Centennial amount */
    public static final int CENTENNIAL = 100;

    /** Quatercennial amount */
    public static final int QUATERCENTENNIAL = 400;

    /** Days in February on leap year */
    public static final int FEB_LEAP_DAYS = 29;

    /** Days in February on normal year */
    public static final int FEB_DAYS = 28;

    /** Days in longer months */
    public static final int LONG_MONTHS = 31;

    /** Days in shorter months */
    public static final int SHORT_MONTHS = 30;

    /** Constant for not found return value */
    public static final int NOT_FOUND = -1;

    /** Size to grow array */
    public static final int GROW_SIZE = 4;

    /** Age limit */
    public static final int AGE_LIMIT = 16;

    /** Full-time Resident Tuition */
    public static final int FULL_RES_TUITION = 12536;

    /** Full-time Non-Resident and International Tuition */
    public static final int FULL_NONRES_INT_TUITION = 29737;

    /** University Fee */
    public static final int UNIVERSITY_FEE = 3268;

    /** Part-time University Fee */
    public static final double PART_UNI_FEE = 0.8 * UNIVERSITY_FEE;

    /** Health Insurance Fee */
    public static final int HEALTH_INSURANCE = 2650;

    /** Part-time Resident Tuition Rate */
    public static final int PART_RES_TUITION_RATE = 404;

    /** Part-time Non-resident Tuition Rate */
    public static final int PART_NONRES_RATE = 966;

    /** Five Parameters */
    public static final int FIVE_PARAM = 5;

    /** Four Parameters */
    public static final int FOUR_PARAM = 4;

    /** Three Parameters */
    public static final int THREE_PARAM = 3;

    /** One Parameter */
    public static final int ONE_PARAM = 1;

    /** Minimum Credits */
    public static final int MIN_CRED = 3;

    /** Maximum Credits */
    public static final int MAX_CRED = 24;

    /** International Credits Threshold */
    public static final int INT_CRED = 12;

    /** NY State Discount */
    public static final int NY_DISC = 4000;

    /** CT State Discount */
    public static final int CT_DISC = 5000;
}
