/**
 * Resident object class that extends Student and is used throughout the project.
 * @author Marlon Vergara
 * @author Luis Castellanos
 */
public class Resident extends Student {
    /** integer to represent the scholarship amount */
    private int scholarship;

    /**
     * Constructor for a Resident student with no parameters.
     */
    public Resident() {
        super();
        this.scholarship = 0;
    }

    /**
     * Constructor for a Resident student with all parameters.
     * @param prf profile as a Profile object.
     * @param mjr major as a Major datatype.
     * @param cred credits as an integer.
     */
    public Resident(Profile prf, Major mjr, int cred) {
        super(prf, mjr, cred);
        this.scholarship = 0;
    }

    /**
     * Sets the scholarship to a specified amount.
     * @param schol amount that the scholarship will be set to.
     */
    public void setScholarship(int schol) {
        this.scholarship = schol;
    }

    /**
     * Gets the scholarship amount.
     * @return scholarship as an integer.
     */
    public int getScholarship() {
        return scholarship;
    }

    /**
     * Overrides the toString() method.
     * @return "(resident)" because it is a resident.
     */
    @Override
    public String toString() {
        return "(resident)";
    }

    /**
     * Checks to see if creditsEnrolled is valid.
     * @param creditsEnrolled credits enrolled as an integer.
     * @return how much tuition is due as a double.
     */
    @Override
    public boolean isValid(int creditsEnrolled) {
        if (creditsEnrolled < Constants.MIN_CRED || creditsEnrolled > Constants.MAX_CRED) {
            return false;
        }
        return true;
    }

    /**
     * Returns tuition due as a double.
     * @param creditsEnrolled credits enrolled as an integer.
     * @return double that represents how much tuition there is.
     */
    @Override // FULL TIME
    public double tuitionDue(int creditsEnrolled) {
        if (creditsEnrolled < 12) {
            return Constants.PART_UNI_FEE + Constants.PART_RES_TUITION_RATE * (creditsEnrolled);
        } else if (creditsEnrolled <= 16 && scholarship > 0) {
            return Constants.UNIVERSITY_FEE + Constants.FULL_RES_TUITION - scholarship;
        } else if (creditsEnrolled <= 16) {
            return Constants.UNIVERSITY_FEE + Constants.FULL_RES_TUITION;
        } else if (scholarship > 0) {
            return Constants.UNIVERSITY_FEE + Constants.FULL_RES_TUITION + Constants.PART_RES_TUITION_RATE
                    * (creditsEnrolled - 16) - scholarship;
        } else if (scholarship <= 10000) {
            return Constants.UNIVERSITY_FEE + Constants.FULL_RES_TUITION + Constants.PART_RES_TUITION_RATE * (creditsEnrolled - 16);
        }
        return Constants.NOT_FOUND;
    }

    /**
     * Checks if object is a resident.
     * @return true because it is a resident.
     */
    @Override
    public boolean isResident() {
        return true;
    }
}
