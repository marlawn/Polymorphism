/**
 * NonResident object class that extends NonResident and is used throughout the project.
 * @author Marlon Vergara
 * @author Luis Castellanos
 */
public class NonResident extends Student {

    /**
     * Constructor for a NonResident student with no parameters.
     */
    public NonResident() {
        super();
    }

    /**
     * Constructor for a NonResident student with all parameters.
     * @param prf profile as a Profile object.
     * @param mjr major as a Major datatype.
     * @param crd credits as an integer.
     */
    public NonResident(Profile prf, Major mjr, int crd) {
        super(prf, mjr, crd);
    }

    /**
     * Returns tuition due as an integer.
     * @param creditsEnrolled credits enrolled as an integer.
     * @return how much tuition is due as a double.
     */
    @Override
    public double tuitionDue(int creditsEnrolled) {
        if (creditsEnrolled < 12) {
            return Constants.PART_NONRES_RATE * creditsEnrolled + Constants.PART_UNI_FEE;
        } else if (creditsEnrolled <= 16) {
            return Constants.FULL_NONRES_INT_TUITION + Constants.UNIVERSITY_FEE;
        }
        return Constants.NOT_FOUND;
    }

    /**
     * Overrides the toString() method
     * @return "(non-resident)"
     */
    @Override
    public String toString() {
        return "(non-resident)";
    }

    /**
     * Checks to see if creditsEnrolled is valid.
     * @param creditsEnrolled credits enrolled as an integer.
     * @return true if credits are valid, false otherwise.
     */
    @Override
    public boolean isValid(int creditsEnrolled) {
        if (creditsEnrolled < Constants.MIN_CRED || creditsEnrolled > Constants.MAX_CRED) {
            return false;
        }
        return true;
    }

    /**
     * Checks if student is resident.
     * @return false because it is a resident.
     */
    @Override
    public boolean isResident() {
        return false;
    }
}
