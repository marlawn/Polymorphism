/**
 * Enrollment class used in TuitionManager
 * @author Marlon Vergara
 * @author Luis Castellanos
 */
public class Enrollment {
    /** enrollStudents as a EnrollStudent array */
    private EnrollStudent[] enrollStudents;
    /** size as an integer */
    private int size;

    /**
     * Constructor for Enrollment with no parameters.
     */
    public Enrollment() {
        this.enrollStudents = new EnrollStudent[4];
        this.size = 0;
    }

    public EnrollStudent[] getEnrollStudentsArr() { return enrollStudents; }

    /**
     * Gets the size
     * @return an integer representing the size.
     */
    public int getSize() {
        return size;
    }

    /**
     * Gets the student.
     * @param enrstd student to get.
     * @return the student that is needed.
     */
    public EnrollStudent getEnrollStudent(EnrollStudent enrstd) {
        return enrollStudents[find(enrstd)];
    }

    /**
     * Grows the array by 4
     */
    private void grow() {
        int temp = size + Constants.GROW_SIZE;
        EnrollStudent[] newEnrollStudents = new EnrollStudent[temp];
        for (int i = 0; i < size; i++) {
            newEnrollStudents[i] = enrollStudents[i];
        }
        this.enrollStudents = newEnrollStudents;
    }

    /**
     * Finds the index of a student
     * @param student student to find the index of
     * @return the index of the student in this array
     */
    private int find(EnrollStudent student) {
        for (int i = 0; i < size; i++) {
            if (enrollStudents[i].compareTo(student) == 0) return i;
        }
        return Constants.NOT_FOUND;
    }

    /**
     * Finds the index of a student
     * @param prf profile to find the index off
     * @return the index of the student in this array
     */
    private int find(Profile prf) {
        for (int i = 0; i < size; i++) {
            if (enrollStudents[i].getESProfile().compareTo(prf) == 0) return i;
        }
        return Constants.NOT_FOUND;
    }

    /**
     * Checks if this contains student.
     * @param student to test if Enrollment contains or not.
     * @return true if it contains the student, false otherwise
     */
    public boolean contains(EnrollStudent student) {
        if (find(student) == Constants.NOT_FOUND) return false;
        return true;
    }

    /**
     * Checks if this contains student.
     * @param prf to test if Enrollment contains or not.
     * @return true if it contains the student, false otherwise
     */
    public boolean contains(Profile prf) {
        if (find(prf) == Constants.NOT_FOUND) return false;
        return true;
    }

    /**
     * Adds student to Enrollment
     * @param newStudent student to be added to Enrollment.
     */
    public void add(EnrollStudent newStudent){
        if (size == enrollStudents.length) grow();
        enrollStudents[size] = newStudent;
        this.size++;
    }

    /**
     * Removes student to Enrollment
     * @param newStudent student to be removed from Enrollment.
     */
    public void remove(EnrollStudent newStudent){
        int index = find(newStudent);
        for (int i = index; i < size - 1; i++) {
            this.enrollStudents[i] = this.enrollStudents[i+1];
        }
        this.enrollStudents[size-1] = null;
        this.size--;
    }

    /**
     * Prints the students in order.
     */
    public void print(){
        for (int i = 0; i < size; i++) {
            System.out.println(enrollStudents[i].getESProfile().getFname() + " " + enrollStudents[i].getESProfile().getLname()
                + " " + enrollStudents[i].getESProfile().getDob().toString() + ": credits enrolled: "
                + enrollStudents[i].getCreditsEnrolled());
        }
    }

    /**
     * Prints the students with the tuition
     */
    public void printTuition() {
        for (int i = 0; i < size; i++) {
            System.out.println(enrollStudents[i].getESProfile().getFname() + " " + enrollStudents[i].getESProfile().getLname() + " " +
                    enrollStudents[i].getESProfile().getDob().toString() + " enrolled "
                    + enrollStudents[i].getCreditsEnrolled() + " credits: tuition due: $");
        }
    }
}
