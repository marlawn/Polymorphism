import org.junit.Test;

import static org.junit.Assert.*;

public class DateTest {

    @Test
    public void test_isValid_daysInFeb_nonLeap() {
        Date date = new Date("2/29/2003");
        assertFalse(date.isValid());
    }

    @Test
    public void test_isValid_daysInApr() {
        Date date = new Date("4/31/2003");
        assertFalse(date.isValid());
    }

    @Test
    public void test_isValid_monthsInYear() {
        Date date = new Date("13/31/2003");
        assertFalse(date.isValid());
    }

    @Test
    public void test_isValid_daysInMar() {
        Date date = new Date("3/32/2003");
        assertFalse(date.isValid());
    }

    @Test
    public void test_isValid_negMonth() {
        Date date = new Date("-1/31/2003");
        assertFalse(date.isValid());
    }

    @Test
    public void test_isValid_corrDate1() {
        Date date = new Date("9/2/2022");
        assertTrue(date.isValid());
    }

    @Test
    public void test_isValid_corrDate2() {
        Date date = new Date("12/20/2004");
        assertTrue(date.isValid());
    }
}