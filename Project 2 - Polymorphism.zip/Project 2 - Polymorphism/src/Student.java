/**
 * Student object used in Roster class
 * @author Marlon Vergara
 * @author Luis Castellanos
 */
public abstract class Student implements Comparable<Student>{
    /** Profile object for Student */
    private Profile profile;

    /** Major object for Student */
    private Major major;

    /** credits completed for Student */
    private int creditsCompleted;

    public Student() {
        this.profile = null;
        this.major = null;
        this.creditsCompleted = 0;
    }

    /**
     * Constructor for Student object which contains profile, major, and credits completed.
     * @param prf Profile object for profile.
     * @param mjr enum value for Major.
     * @param crd integer representing credits completed.
     */
    public Student(Profile prf, Major mjr, int crd) {
        this.profile = prf;
        this.major = mjr;
        this.creditsCompleted = crd;
    }

    /**
     * Constructor for Student object with only profile.
     * major is set to null and creditsCompleted is set to 0.
     * @param prf Profile object for profile.
     */
    public Student(Profile prf) {
        this.profile = prf;
        this.major = null;
        this.creditsCompleted = 0;
    }

    /**
     * Get profile.
     * @return profile as Profile object.
     */
    public Profile getProfile() {
        return profile;
    }

    /**
     * Get major.
     * @return major as Major enum value.
     */
    public Major getMajor() {
        return major;
    }

    /**
     * Set major.
     * @param mjr major to be set.
     */
    public void setMajor(Major mjr) {
        this.major = mjr;
    }

    /**
     * Gets amount of credits completed.
     * @return credits completed as integer.
     */
    public int getCreditsCompleted() {
        return creditsCompleted;
    }

    /**
     * Adds credits to creditsCompleted
     * @param credits integer that represents credits
     */
    public void addCredits(int credits) { this.creditsCompleted = creditsCompleted + credits; }

    /**
     * Gets standing in class (Freshman, Sophomore, Junior, Senior)
     * @return standing as a String
     */
    public String getStanding() {
        if (this.creditsCompleted < 30) return "Freshman";
        else if (this.creditsCompleted < 60) return "Sophomore";
        else if (this.creditsCompleted < 90) return "Junior";
        else return "Senior";
    }

    /**
     * Overrides toString() to a customized output.
     * @return String as "[firstName] [lastName] is majoring in [major] and has completed [creditsCompleted] credits."
     */
    @Override
    public String toString() {
        return this.profile.getFname() + " " + this.profile.getLname() + " is majoring in " + this.major
                + " and has completed " + this.creditsCompleted + " credits.";
    }

    /**
     * Overrides equals(Object obj) to determine if two Profiles are equal.
     * @param obj object to be determined if equal to this Student or not.
     * @return true if the object equals the Profile, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (!(obj instanceof Student)) return false;
        Student s = (Student) obj;
        return s.getProfile().equals(this.profile) && s.getMajor().equals(this.major) && s.getCreditsCompleted() == this.creditsCompleted;
    }

    /**
     * Overrides compareTo(Student std)
     * @param std the object to be compared.
     * @return -1 if this student is before std, 1 if this student is after std, 0 if equal
     */
    @Override
    public int compareTo(Student std) {
        if (!this.profile.equals(std.getProfile())) { return this.profile.compareTo(std.getProfile()); }
        return 0;
    }

    public boolean isValid(int creditsEnrolled) {
        return true;
    }

    public abstract double tuitionDue(int creditsEnrolled);
    public abstract boolean isResident();

}
