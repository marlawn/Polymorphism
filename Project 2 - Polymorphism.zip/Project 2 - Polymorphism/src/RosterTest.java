import org.junit.Test;

import static org.junit.Assert.*;

public class RosterTest {

    Roster r = new Roster();

    @Test
    public void test_add_International_true() {
        Date date = new Date("4/12/2002");
        Profile prf = new Profile("Marlon", "Vergara", date);
        International intl = new International(prf, Major.EE, 60, true);
        assertTrue(r.add(intl));
    }

    @Test
    public void test_add_International_false() {
        Date date = new Date("4/12/2002");
        Profile prf = new Profile("Marlon", "Vergara", date);
        International intl = new International(prf, Major.EE, 60, true);
        r.add(intl);
        assertFalse(r.add(intl));
    }

    @Test
    public void test_add_TriState_true() {
        Date date = new Date("4/12/2002");
        Profile prf = new Profile("Marlon", "Vergara", date);
        TriState trst = new TriState(prf, Major.EE, 60, "NY");
        assertTrue(r.add(trst));
    }

    @Test
    public void test_add_TriState_false() {
        Date date = new Date("4/12/2002");
        Profile prf = new Profile("Marlon", "Vergara", date);
        TriState trst = new TriState(prf, Major.EE, 60, "NY");
        r.add(trst);
        assertFalse(r.add(trst));
    }
}