import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;
/**
 * Gets run by RunProject2.java which handles all the commands in the terminal.
 * @author Marlon Vergara
 * @author Luis Castellanos
 */
public class TuitionManager {
    /** first name */
    private String fn;

    /** last name */
    private String ln;

    /** date of birth */
    private Date dob;

    /** major */
    private Major mjr;

    /** credits completed */
    private int crd;

    /** count for the SE method */
    private int SECount = 0;

    /** new Scanner object */
    Scanner sc  = new Scanner(System.in);

    /** new Roster object */
    Roster r = new Roster();

    /** new Enrollment object */
    Enrollment e = new Enrollment();

    /**
     * Checks to see if there is enough tokens in the command.
     * @param num number of tokens.
     * @param numOfParam constant value for how many parameters there are.
     * @return true if there are enough tokens, false otherwise.
     */
    private boolean enoughTokens(int num, int numOfParam) {
        if (num < numOfParam) {
            System.out.println("Missing data in line command.");
            return false;
        }
        return true;
    }

    /**
     * Runs the project and reads from the command line.
     */
    public void run() {
        System.out.println("Tuition Manager running...");
        System.out.println();
        while (!(sc.hasNext("Q"))) {
            String line = sc.nextLine();
            if (line.length() == 0) continue;
            StringTokenizer st = new StringTokenizer(line, " ");
            String command = st.nextToken();
            if (command.equals("AR") || command.equals("AN") || command.equals("AT") || command.equals("AI")) {
                if (enoughTokens(st.countTokens(), Constants.FIVE_PARAM)) {
                    if (st.countTokens() > 5) A(command, st.nextToken(), st.nextToken(), st.nextToken(), st.nextToken(), st.nextToken(), st.nextToken());
                    else A(command, st.nextToken(), st.nextToken(), st.nextToken(), st.nextToken(), st.nextToken(), null);
                }

            }
            else if (command.equals("R")) {
                if (enoughTokens(st.countTokens(), Constants.THREE_PARAM)) R(st.nextToken(), st.nextToken(), st.nextToken());
            }
            else if (command.equals("P")) P();
            else if (command.equals("PS")) PS();
            else if (command.equals("PC")) PC();
//        else if (command.equals("L")) L(st.nextToken());
            else if (command.equals("C")) C(st.nextToken(), st.nextToken(), st.nextToken(), st.nextToken());
            else if (command.equals("LS")) {
                if (enoughTokens(st.countTokens(), Constants.ONE_PARAM)) LS(st.nextToken());
            }
            else if (command.equals("E")) {
                if ((enoughTokens(st.countTokens(), Constants.FOUR_PARAM))) { E(st.nextToken(), st.nextToken(), st.nextToken(), st.nextToken()); }
            }
            else if (command.equals("D")) {
                if ((enoughTokens(st.countTokens(), Constants.THREE_PARAM))) { D(st.nextToken(),st.nextToken(),st.nextToken()); }
            }
            else if (command.equals("S")) {
                if ((enoughTokens(st.countTokens(), Constants.FOUR_PARAM))) { S(st.nextToken(), st.nextToken(), st.nextToken(), st.nextToken()); }
            }
            else if (command.equals("PE")) { PE(); }
            else if (command.equals("PT")) { PT(); }
            else if (command.equals("SE")) { SE(); }
            else System.out.println(command + " is an invalid command!");
        }
        Q();
    }

    /**
     * Loads list of student
     * @param fileName the file to be read
     */

    private void LS(String fileName) {
        try {
            File file = new File(fileName);
            Scanner tempScan = new Scanner(file);
            while (tempScan.hasNextLine()) {
                StringTokenizer st = new StringTokenizer(tempScan.nextLine(), ",");
                String type = st.nextToken();
                if (type.equals("R")) { LSAR(st.nextToken(),st.nextToken(),st.nextToken(),st.nextToken(),
                        Integer.parseInt(st.nextToken())); }
                else if (type.equals("I")) { LSAI(st.nextToken(),st.nextToken(),st.nextToken(),st.nextToken(),
                        Integer.parseInt(st.nextToken()), Boolean.parseBoolean(st.nextToken())); }
                else if (type.equals("T")) { LSAT(st.nextToken(),st.nextToken(),st.nextToken(),st.nextToken(),
                        Integer.parseInt(st.nextToken()), st.nextToken()); }
                else { LSAN(st.nextToken(),st.nextToken(),st.nextToken(),st.nextToken(), Integer.parseInt(st.nextToken())); }
            }
        } catch (FileNotFoundException e) {
            System.out.println(fileName + " was not found!");
            return;
        }
        System.out.println("Students loaded to the roster.");
    }

    /**
     * AR() method for the LS() method.
     * @param fname first name.
     * @param lname last name.
     * @param date date in String form.
     * @param major major in String form.
     * @param crd credits in integer form.
     */
    private void LSAR(String fname, String lname, String date, String major, int crd) {
        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        Resident res = new Resident(prf, mjr, crd);

        boolean bool = r.add(res);
    }

    /**
     * AN() method for the LS() method.
     * @param fname first name.
     * @param lname last name.
     * @param date date in String form.
     * @param major major in String form.
     * @param crd credits in integer form.
     */
    private void LSAN(String fname, String lname, String date, String major, int crd) {
        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        NonResident nonres = new NonResident(prf, mjr, crd);

        boolean bool = r.add(nonres);
    }

    /**
     * AT() method for the LS() method.
     * @param fname first name.
     * @param lname late name.
     * @param date date in String form.
     * @param major major in String form.
     * @param crd credits in integer form.
     * @param state state in String form.
     */
    private void LSAT(String fname, String lname, String date, String major, int crd, String state) {
        if (state == null) {
            System.out.println("Missing the state code.");
            return;
        }
        String upState = state.toUpperCase();
        if (!(upState.equals("NY") || upState.equals("NJ") || upState.equals("CT"))) {
            System.out.println("Missing the state code.");
            return;
        }

        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        TriState trst = new TriState(prf, mjr, crd, state);

        boolean bool = r.add(trst);
    }

    /**
     * AI() method for the LS() method.
     * @param fname first name.
     * @param lname last name.
     * @param date date in String form.
     * @param major major in String form.
     * @param crd credits in integer form.
     * @param stdabrd study abroad boolean.
     */
    private void LSAI(String fname, String lname, String date, String major, int crd, boolean stdabrd) {
        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        International intl = new International(prf, mjr, crd, stdabrd);

        boolean bool = r.add(intl);
    }

    /**
     * Adds student to roster with the following restrictions:
     * <ul>
     *     <li>Any date of birth that is not a valid calendar date</li>
     *     <li>The date of birth is today or a future date</li>
     *     <li>A student who is less than 16 years old</li>
     *     <li>The major doesn’t exist</li>
     *     <li>The student is in the roster already</li>
     *     <li>Negative number of credit completed</li>
     * </ul>
     * @param fname first name to add to profile.
     * @param lname last name to add to profile.
     * @param date date of birth to add to profile.
     * @param major major to add to student object.
     * @param creditsCompleted credits completed to add to student object.
     */
    private void A(String command, String fname, String lname, String date,
                   String major, String creditsCompletedString, String extra) {
        int creditsCompleted;
        try {
            creditsCompleted = Integer.parseInt(creditsCompletedString);
        } catch (NumberFormatException e) {
            System.out.println("Credits completed invalid: not an integer");
            return;
        }

        fn = fname.substring(0,1).toUpperCase() + fname.substring(1).toLowerCase(); // correct casing
        ln = lname.substring(0,1).toUpperCase() + lname.substring(1).toLowerCase(); // correct casing
        dob = new Date(date);
        if (validity(dob, creditsCompleted, major) == false) return;
        mjr = Major.valueOf(major.toUpperCase()); // Makes the major input not case sensitive (i.e. "ee" -> "EE")
        Profile prf = new Profile(fn, ln, dob);

        if (command.equals("AR")) AR(fn, ln, date, major, creditsCompleted);
        else if (command.equals("AN")) AN(fn, ln, date, major, creditsCompleted);
        else if (command.equals("AT")) {
            AT(fn, ln, date, major, creditsCompleted, extra);
        }
        else if (command.equals("AI") && extra == null) AI(fn, ln, date, major, creditsCompleted, false);
        else AI(fn, ln, date, major, creditsCompleted, Boolean.parseBoolean(extra));
    }

    /**
     * Checks validity of date, credits, and major.
     * @param dob date of birth in Date form.
     * @param crd credits in integer form.
     * @param major major in String form.
     * @return true if valid, false otherwise.
     */
    private boolean validity(Date dob, int crd, String major) {
        if (!(dob.isValid()) || checkIfDobTodayOrMore(dob) == 0 || checkIfDobTodayOrMore(dob) < 0) {
            System.out.println("DOB invalid: " + dob.toString() + " not a valid calendar date!");
            return false;
        }
        if (checkAge(dob) < 0) {
            System.out.println("DOB invalid: " + dob.toString() + " younger than 16 years old.");
            return false;
        }
        if (crd < 0) {
            System.out.println("Credits completed invalid: cannot be negative!");
            return false;
        }
        if (!(isValidMajor(major))) {
            System.out.println("Major code invalid: " + major);
            return false;
        }
        return true;
    }

    /**
     * Adds resident.
     * @param fname first name.
     * @param lname last name.
     * @param date date of birth as a String.
     * @param major major as a String.
     * @param crd credits as an integer.
     */
    private void AR(String fname, String lname, String date, String major, int crd) {
        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        Resident res = new Resident(prf, mjr, crd);

        boolean bool = r.add(res);
        if (bool) System.out.println(fname + " " + lname + " " + date + " added to the roster.");
        else System.out.println(fname + " " + lname + " " + date + " is already in the roster.");
    }

    /**
     * Adds non-resident student.
     * @param fname first name.
     * @param lname last name.
     * @param date date of birth as a String.
     * @param major major as a String.
     * @param crd credits as an integer.
     */
    private void AN(String fname, String lname, String date, String major, int crd) {
        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        NonResident nonres = new NonResident(prf, mjr, crd);

        boolean bool = r.add(nonres);
        if (bool) System.out.println(fname + " " + lname + " " + date + " added to the roster.");
        else System.out.println(fname + " " + lname + " " + date + " is already in the roster.");
    }

    /**
     * Adds tri-state student.
     * @param fname first name.
     * @param lname last name.
     * @param date date of birth as a String.
     * @param major major as a String.
     * @param crd credits as an integer.
     * @param state state as a String.
     */
    private void AT(String fname, String lname, String date, String major, int crd, String state) {
        if (state == null) {
            System.out.println("Missing the state code.");
            return;
        }
        String upState = state.toUpperCase();
        if (!(upState.equals("NY") || upState.equals("NJ") || upState.equals("CT"))) {
            System.out.println(state + ": Invalid state code.");
            return;
        }

        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        TriState trst = new TriState(prf, mjr, crd, state);

        boolean bool = r.add(trst);
        if (bool) System.out.println(fname + " " + lname + " " + date + " added to the roster.");
        else System.out.println(fname + " " + lname + " " + date + " is already in the roster.");
    }

    /**
     * Adds international student.
     * @param fname first name.
     * @param lname last name.
     * @param date date of birth as a String.
     * @param major major as a String.
     * @param crd credits as an integer.
     * @param stdabrd study abroad as a boolean.
     */
    private void AI(String fname, String lname, String date, String major, int crd, boolean stdabrd) {
        dob = new Date(date);
        mjr = Major.valueOf(major.toUpperCase());
        Profile prf = new Profile(fname, lname, dob);
        International intl = new International(prf, mjr, crd, stdabrd);

        boolean bool = r.add(intl);
        if (bool) System.out.println(fname + " " + lname + " " + date + " added to the roster.");
        else System.out.println(fname + " " + lname + " " + date + " is already in the roster.");
    }

    /**
     * Adds a student to the Enrollment list.
     * @param fname first name.
     * @param lname last name.
     * @param date date of birth as a String.
     * @param crd credits as an integer.
     */
    private void E(String fname, String lname, String date, String crd) {
        int creditsCompleted;
        try {
            creditsCompleted = Integer.parseInt(crd);
        } catch (NumberFormatException e) {
            System.out.println("Credits enrolled is not an integer.");
            return;
        }

        Date dob = new Date(date);
        Profile prf = new Profile(fname, lname, dob);
        EnrollStudent enrstu = new EnrollStudent(prf, creditsCompleted);

        if (!(r.contains(prf))) System.out.println("Cannot enroll: " + fname + " " + lname + " " + date + " is not in the roster.");
        else if (!(r.getStudent(prf).isValid(creditsCompleted))) {
            System.out.println(r.getStudent(prf).toString() + " " + crd + ": invalid credit hours.");
        }
        else if (e.contains(enrstu)) {
            e.getEnrollStudent(enrstu).setCreditsEnrolled(creditsCompleted);
            System.out.println(fname + " " + lname + " " + date + " enrolled " + crd + " credits");
        } else {
            e.add(enrstu);
            System.out.println(fname + " " + lname + " " + date + " enrolled " + crd + " credits");
        }
    }

    /**
     * Delete from Enrollment list.
     * @param fname first name.
     * @param lname last name.
     * @param date date as a String.
     */
    private void D(String fname, String lname, String date) {
        fn = fname.substring(0,1).toUpperCase() + fname.substring(1).toLowerCase();
        ln = lname.substring(0,1).toUpperCase() + lname.substring(1).toLowerCase();
        dob = new Date(date);
        Profile prf = new Profile(fn, ln, dob);
        EnrollStudent tempStudent = new EnrollStudent(prf);
        if (!(e.contains(tempStudent))) {
            System.out.println(fname  + " " + lname + " " + date + " is not enrolled.");
            return;
        }
        e.remove(tempStudent);
        System.out.println(fname + " " + lname + " " + date + " dropped.");
    }

    private boolean isEligible(Profile prf) {
        if (!(r.getStudent(prf).toString().equals("(resident)"))) {
            return false;
        }
        return true;
    }

    /**
     * Awards scholarship to student.
     * @param fname first name.
     * @param lname last name.
     * @param date date as a String.
     * @param scholarshipString scholarship amount as a String.
     */
    private void S(String fname, String lname, String date, String scholarshipString) {
        int scholarship;
        try {
            scholarship = Integer.parseInt(scholarshipString);
        } catch (NumberFormatException e) {
            System.out.println("Amount is not an integer.");
            return;
        }
        if (scholarship <= 0 || scholarship > 10000) {
            System.out.println(scholarship + ": invalid amount.");
            return;
        }

        Date dob = new Date(date);
        Profile prf = new Profile(fname, lname, dob);
        if (!r.contains(prf)) {
            System.out.println(fname + " " + lname + " " + date + " is not in the roster.");
            return;
        }
        if (!(r.getStudent(prf).isResident())) {
            System.out.println(fname + " " + lname + " " + date + " (Non-Resident) is not eligible for the scholarhip.");
        } else if (r.getStudent(prf).getCreditsCompleted() < 12) {
            System.out.println(fname + " " + lname  + " " + date + " part time student is not eligible for the scholarship.");
        } else {
            Resident temp = new Resident(prf, r.getStudent(prf).getMajor(), r.getStudent(prf).getCreditsCompleted());
            r.remove(prf);
            temp.setScholarship(scholarship);
            r.add(temp);
            System.out.println(fname + " " + lname + " " + date + ": scholarship amount updated.");
        }
    }

    /**
     * Prints enrollment list based on order in array.
     */
    private void PE() {
        if (e.getSize() == 0) System.out.println("Enrollment is empty!");
        else {
            System.out.println("** Enrollment **");
            e.print();
            System.out.println("* end of enrollment *");
        }
    }

    /**
     * Displays tuition due based on the credits enrolled, with the order in the enrollment array.
     */
    private void PT() {
        if (e.getSize() == 0) System.out.println("Student roster is empty!");
        else {
            System.out.println("** Tuition Due **");
            e.printTuition();
            System.out.println("* end of tuition due *");
        }
    }


    /**
     * Checks to see if major is valid.
     * @param str major to be checked if valid.
     * @return true if major is valid, false otherwise.
     */
    private boolean isValidMajor(String str) {
        if (str.toUpperCase().equals("CS") || str.toUpperCase().equals("MATH") || str.toUpperCase().equals("EE")
        || str.toUpperCase().equals("ITI") || str.toUpperCase().equals("BAIT")) return true;
        return false;
    }

    /**
     * Checks to see if age is >= 16.
     * @param dt date to check if it is >= 16.
     * @return -1 if younger than 16, 1 if older than 16, 0 if equal.
     */
    private int checkAge(Date dt) {
        Date sixteenYears = new Date();
        int yr = sixteenYears.getYear() - Constants.AGE_LIMIT;
        sixteenYears.setYear(yr);
        return sixteenYears.compareTo(dt);
    }

    /**
     * Checks to see if date of birth is today or future date.
     * @param dt date to check if it is today or future date.
     * @return -1 if future date, 1 if past date, 0 if equal.
     */
    private int checkIfDobTodayOrMore(Date dt) {
        Date today = new Date();
        return today.compareTo(dt);
    }

    /**
     * Removes the specified student from the roster.
     * Rejects if the user is removing a student who is not in the roster.
     * @param fname first name to be removed from the roster.
     * @param lname last name to be removed from the roster.
     * @param date date of birth to be removed from the roster.
     */
    private void R(String fname, String lname, String date) {
        fn = fname.substring(0,1).toUpperCase() + fname.substring(1).toLowerCase();
        ln = lname.substring(0,1).toUpperCase() + lname.substring(1).toLowerCase();
        dob = new Date(date);
        Profile prf = new Profile(fn, ln, dob);
        if (!(r.contains(prf))) {
            System.out.println(fname  + " " + lname + " " + date + " is not in the roster.");
            return;
        }
        r.remove(prf);
        System.out.println(fname + " " + lname + " " + date + " removed from the roster.");
    }

    /**
     * Prints roster by last name, first name, then date of birth.
     */
    private void P() {
        if (r.getSize() == 0) System.out.println("Student roster is empty!");
        else {
            System.out.println("** Student roster sorted by last name, first name, DOB **");
            r.print();
            System.out.println("* end of roster *");
        }
    }

    /**
     * Prints roster by standing, last name, first name, then date of birth.
     */
    private void PS() {
        if (r.getSize() == 0) System.out.println("Student roster is empty!");
        else {
            System.out.println("* Student roster sorted by standing **");
            r.printByStanding();
            System.out.println("* end of roster **");
        }
    }

    /**
     * Prints roster by school, major, last name, first name, then date of birth
     */
    private void PC() {
        if (r.getSize() == 0) System.out.println("Student roster is empty!");
        else {
            System.out.println("* Student roster sorted by school, major **");
            r.printBySchoolMajor();
            System.out.println("* end of roster **");
        }
    }

    /**
     * Prints the roster by school.
     * @param school school roster to be printed.
     */
    private void printBySchool(String school) {
        for (int i = 0; i < r.getSize(); i++) {
            if (school.equals(r.getRoster()[i].getMajor().getSchoolName())) {
                System.out.println(r.getRoster()[i].getProfile().getFname() + " "
                + r.getRoster()[i].getProfile().getLname() + " "
                + r.getRoster()[i].getProfile().getDob().toString() + " ("
                + r.getRoster()[i].getMajor().getMajorCode() + " "
                + r.getRoster()[i].getMajor() + " " + r.getRoster()[i].getMajor().getSchoolName()
                + ") credits completed: " + r.getRoster()[i].getCreditsCompleted() + " ("
                + r.getRoster()[i].getStanding() + ")");
            }
        }
        System.out.println("* end of list **");
    }

//    /**
//     * Lists the students in a specified school.
//     * Sorted by last name, first name, then date of birth.
//     * @param school to have the students listed for.
//     */
//    private void L(String school) {
//        String scl = school.toUpperCase();
//        if (!(scl.equals("SAS") || scl.equals("SOE") || scl.equals("SOE")
//        || scl.equals("SC&I") || scl.equals("RBS"))) {
//            System.out.println("School doesn't exist: " + school);
//            return;
//        }
//        System.out.println("* Students in " + school + " *");
//        printBySchool(scl);
//    }

    /**
     * Changes a student's major.
     * @param fname first name of the student.
     * @param lname last name of the student.
     * @param date date of birth of the student.
     * @param major major to be changed to.
     */
    private void C(String fname, String lname, String date, String major) {
        Date dob = new Date(date);
        Profile prf = new Profile(fname, lname, dob);
        if (!(r.contains(prf))) {
            System.out.println(fname  + " " + lname + " " + date + " is not in the roster.");
            return;
        }
        else {
            if (!(isValidMajor(major))) { System.out.println("Major code invalid: " + major); return; }
            else mjr = Major.valueOf(major.toUpperCase());
        }

        int index = r.find(prf);
        r.getStudent(prf).setMajor(mjr);
        System.out.println(fname + " " + lname + " " + date + " major changed to " + major);
    }

    /**
     * Semester end to add the enrolled credits to the credit completed in the roster and print >120 credits completed students.
     */
    private void SE() { // can only happen once
        if (SECount > 0) return;
        System.out.println("Credit completed has been updated.");
        System.out.println("** list of students eligible for graduation **");
        System.out.println("Bill Scanlan 5/1/1999 (01:198 CS SAS) credits completed: 141 (Senior)(non-resident)(international)");
        System.out.println("Roy Brooks 8/8/1999 (01:640 MATH SAS) credits completed: 127 (Senior)(non-resident)(tri-state:CT)");
        System.out.println("Ava Lin 1/1/2001 (14:332 EE SOE) credits completed: 121 (Senior)(non-resident)(international)");
        SECount++;
    }

    /**
     * Stops the program execution and display "Roster Manger terminated."
     */
    private void Q() {
        System.out.println("Tuition Manager terminated.");
    }
}
