import org.junit.Test;

import static org.junit.Assert.*;

public class InternationalTest {

    @Test
    public void test_tuitionDue_studyAbroad() {
        Date date = new Date("4/12/2002");
        Profile prf = new Profile("Marlon", "Vergara", date);
        International intl = new International(prf, Major.EE, 60, true);
        assertEquals(Constants.UNIVERSITY_FEE + Constants.HEALTH_INSURANCE, intl.tuitionDue(16), 0.02);
    }

    @Test
    public void test_tuitionDue_notStudyAbroad() {
        Date date = new Date("4/12/2002");
        Profile prf = new Profile("Marlon", "Vergara", date);
        International intl = new International(prf, Major.EE, 60, false);
        assertEquals(Constants.UNIVERSITY_FEE + Constants.HEALTH_INSURANCE + Constants.FULL_NONRES_INT_TUITION,
                intl.tuitionDue(16), 0.02);
    }
}